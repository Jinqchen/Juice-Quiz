export const PLACES = 
	[
		{
			id: 0,
			name: 'Classic Music',
			image: './classicMusic.jpg',
			tag: 'music'
		} ,
		{
			id: 1,
			name: 'Pop Music',
			image: './popMusic.jpg',
			tag: 'music'
		}  ,
		{
			id: 2,
			name: 'League of Legend',
			image: './lol.jpg',
			tag: 'game'
		} ,
		{
			id: 3,
			name: 'C++',
			image: './c++.png',
			tag: 'programing'
		} ,
		{
			id: 4,
			name: 'NBA',
			image: './nba.png',
			tag: 'sport'
		} ,
		{
			id: 5,
			name: 'Math',
			image: './math.jpg',
			tag: 'science'
		} ,
		{
			id: 6,
			name: 'Japanese Food',
			image: './jpFood.jpg',
			tag: 'food'
		} ,
		{
			id: 7,
			name: 'Itanlian Food',
			image: './ITfood.jpg',
			tag: 'food'
		}  
 
 
 




	

	
	];